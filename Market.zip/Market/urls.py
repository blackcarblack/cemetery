from django.urls import path
from . import views

urlpatterns = [
     path('', views.index, name='index'),
     path('about/', views.about),
     path('about_me/', views.about_me),
     path('register/', views.register, name='register'),
     path('admin-register/', views.admin_register, name='admin_register'),
     path('login/', views.user_login, name='login'),
     path('admin/add-product/', views.add_product, name='add_product'),
     path('update/<int:pk>/', views.update_product, name='update_product'),
     path('delete/<int:pk>/', views.delete_product, name='delete_product'),
]