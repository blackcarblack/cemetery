import datetime
from django.http import HttpResponseForbidden
from django.http import HttpResponseRedirect
from django.shortcuts import render, redirect
from django.contrib.auth import login, authenticate
from .forms import UserRegistrationForm, AdminRegistrationForm, ProductForm
from django.contrib.auth.decorators import login_required
from .models import Product
from django.urls import reverse
# Create your views here.







def register(request):
    if request.method == 'POST':
        form = UserRegistrationForm(request.POST)
        if form.is_valid():
            user = form.save(commit=False)
            user.set_password(form.cleaned_data['password'])
            user.save()
            return render(request, 'Market/login.html')
    else:
        form = UserRegistrationForm()
    return render(request, 'Market/registration.html', {'form': form})


def admin_register(request):
    if request.method == 'POST':
        form = AdminRegistrationForm(request.POST)
        if form.is_valid():
            admin = form.save(commit=False)
            admin.set_password(form.cleaned_data['password'])
            admin.is_staff = True
            admin.save()
            return render(request, 'Market/login.html')
    else:
        form = AdminRegistrationForm()
    return render(request, 'Market/admin_registration.html', {'form': form})

def user_login(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')
        user = authenticate(username=username, password=password)
        if user:
            login(request, user)
            return render(request, "Market/about_me.html")
    return render(request, 'Market/login.html')

# @login_required
def add_product(request):
    # if not request.user.is_staff:
    #     return HttpResponseForbidden("Доступ тільки для адміністратора.")

    if request.method == 'POST':
        form = ProductForm(request.POST)
        if form.is_valid():
            form.save()
            return render(request, "Market/about_me.html")
    else:
        form = ProductForm()
    return render(request, 'Market/admin_add_product.html', {'form': form})


def about_me(request):
    return render(request, "Market/about_me.html")
def about(request):
    return render(request, "Market/about.html")
def index(request):
    products = Product.objects.all()
    return render(request, "Market/index.html", {'products': products})

def update_product(request, pk):
    product = Product.objects.get(pk=pk)
    if request.method == 'POST':
        form = ProductForm(request.POST, instance=product)
        if form.is_valid():
            form.save()
            return HttpResponseRedirect(reverse('index'))
    else:
        form = ProductForm(instance=product)
    return render(request, 'Market/update_product.html', {'form': form})

def delete_product(request, pk):
    product = Product.objects.get(pk=pk)
    if request.method == 'POST':
        product.delete()
        return HttpResponseRedirect(reverse('index'))
    return render(request, 'Market/delete.html', {'product': product})
